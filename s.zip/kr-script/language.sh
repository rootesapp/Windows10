
echo 正在导入
cp $language $HOME
cd $HOME
tar -xvf *.language
rm -rf *.language
echo 导入完成