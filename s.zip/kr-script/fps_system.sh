echo "service call SurfaceFlinger 1035 i32 $test" >>/data/data/com.root.system/boot.sh
            chmod 777 /data/data/com.root.system/boot.sh
            service call SurfaceFlinger 1035 i32 $test >/dev/null 2>&1