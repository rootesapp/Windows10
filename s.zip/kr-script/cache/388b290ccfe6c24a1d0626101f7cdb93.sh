#Han.GJZS

[[ -d "$DATA_DIR/com.google.android.gms" ]] && echo 1 || echo 0