#Han.GJZS

[[ `getprop debug.hwui.force_dark` = true ]] && echo 1