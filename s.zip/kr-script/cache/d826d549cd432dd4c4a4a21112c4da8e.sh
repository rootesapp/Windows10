#Han.GJZS

settings get secure high_text_contrast_enabled