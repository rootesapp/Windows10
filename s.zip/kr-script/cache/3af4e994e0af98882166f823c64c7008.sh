#Han.GJZS

. $Data_Dir/Random_Install_BootAnimation_Screen2.log; echo "$BootAnimation_Screen2"