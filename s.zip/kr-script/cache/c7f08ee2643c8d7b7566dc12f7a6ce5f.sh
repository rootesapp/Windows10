#Han.GJZS

cat $Pages/Termux.xml