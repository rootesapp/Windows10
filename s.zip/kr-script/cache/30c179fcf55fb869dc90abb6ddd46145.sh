#Han.GJZS

[[ $state = 1 ]] && setprop debug.hwui.force_dark true || setprop debug.hwui.force_dark false