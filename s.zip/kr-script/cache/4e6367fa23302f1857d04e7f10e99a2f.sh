#Han.GJZS

grep_prop install_Way $Data_Dir/Random_Install_BootAnimation_Screen2.log