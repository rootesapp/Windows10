#Han.GJZS

. ./Install_BootAnimation_Screen2_PATH.sh