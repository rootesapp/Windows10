#Han.GJZS

tail -n +2 ./Install_BootAnimation_Screen2_Option.sh