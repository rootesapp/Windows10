#Han.GJZS

echo -n 通过数字值，精准的修改亮度值，当前亮度值为`settings get system screen_brightness`