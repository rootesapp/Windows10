#Han.GJZS

cat ./Install_BootAnimation_Screen1_Option.sh