#Han.GJZS

. ./Install_BootAnimation_Screen1_Format.sh