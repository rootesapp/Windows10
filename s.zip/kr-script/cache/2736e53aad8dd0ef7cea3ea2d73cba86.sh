#Han.GJZS

[[ `settings get secure show_rotation_suggestions` = 0 ]] || echo 1