#Han.GJZS

settings get global force_resizable_activities