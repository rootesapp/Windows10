#Han.GJZS

settings get system status_bar_show_network_speed