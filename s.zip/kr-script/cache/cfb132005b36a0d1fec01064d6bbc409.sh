#Han.GJZS

echo -e 随意修改自动锁屏时间\\n当前自动锁屏时间为`settings get system screen_off_timeout`ms