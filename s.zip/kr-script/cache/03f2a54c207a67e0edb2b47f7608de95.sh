#Han.GJZS

settings get global adb_enabled