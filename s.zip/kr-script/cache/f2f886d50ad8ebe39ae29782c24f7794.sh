#Han.GJZS

. ./Geek/WiFi-2.4G_Speed_Up_Get.sh