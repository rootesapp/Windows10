#Han.GJZS

[[ -f /sys/class/power_supply/battery/input_suspend || -f /sys/class/power_supply/battery/charging_enabled ]] && echo 1