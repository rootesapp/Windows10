#Han.GJZS

[[ true = false]] && echo 1