#Han.GJZS

. ./Obtain_WiFi_ip.sh