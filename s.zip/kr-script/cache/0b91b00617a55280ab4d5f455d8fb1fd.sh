#Han.GJZS

grep_prop Set_Time $Data_Dir/Random_Install_BootAnimation_Screen2.log || echo 2