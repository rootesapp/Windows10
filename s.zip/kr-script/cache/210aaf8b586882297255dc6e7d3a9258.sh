#Han.GJZS

settings get system show_touches