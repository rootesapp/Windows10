#Han.GJZS

[[ `getenforce` = Enforcing ]] && echo 1