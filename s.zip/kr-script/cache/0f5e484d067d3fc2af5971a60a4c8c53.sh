#Han.GJZS

settings get system pointer_location