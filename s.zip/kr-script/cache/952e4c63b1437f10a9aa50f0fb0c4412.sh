#Han.GJZS

. ./switchs/Network_ADB_debugging_get.sh