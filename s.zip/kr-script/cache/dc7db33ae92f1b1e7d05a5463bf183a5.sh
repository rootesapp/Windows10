#Han.GJZS

grep_prop Authority $Data_Dir/Random_Install_BootAnimation_Screen2.log || echo 644