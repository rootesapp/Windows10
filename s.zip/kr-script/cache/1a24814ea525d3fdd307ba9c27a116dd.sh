#Han.GJZS

. $Load com.topjohnwu.magisk; echo "已上传版本：$name-$version($versionCode).zip"