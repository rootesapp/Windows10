#Han.GJZS

. ./Geek/Check_Gesture_Installer.sh