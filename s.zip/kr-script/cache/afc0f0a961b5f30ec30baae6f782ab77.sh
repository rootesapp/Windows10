#Han.GJZS

[[ $SDK -ge 31 ]] && echo 1