#Han.GJZS

echo -e "当前设置的DPI值为`wm density|sed 's/Physical density/默认值/; s/Override density/当前值/'`"