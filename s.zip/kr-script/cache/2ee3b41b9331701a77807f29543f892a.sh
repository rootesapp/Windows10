#Han.GJZS

. ./CheckUpdate.sh