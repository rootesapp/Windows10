#Han.GJZS

[[ -n `which magisk` ]] && echo 1