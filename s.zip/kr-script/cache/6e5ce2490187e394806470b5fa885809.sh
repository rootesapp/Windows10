#Han.GJZS

. ./support/Check_Brand_NO_samsung.sh