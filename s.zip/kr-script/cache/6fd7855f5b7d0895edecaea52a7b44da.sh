#Han.GJZS

grep_prop bootanimation $Data_Dir/Random_Install_BootAnimation_Screen2.log