#Han.GJZS

[[ `getprop sys.sptm.gover` = true ]] && echo 1