#Han.GJZS

. ./switchs/Dark_Mode_Get.sh