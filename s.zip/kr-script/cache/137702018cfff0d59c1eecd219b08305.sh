#Han.GJZS

. $Load AD-Hosts; echo "已上传版本：$name-$version($versionCode)";echo "用途：屏蔽各类广告包括(各大视频网站,运营商劫持广告,大部分APP广告)";. ./Geek/Check_Frame_installation_Status.sh AD-Hosts "AD Hosts"