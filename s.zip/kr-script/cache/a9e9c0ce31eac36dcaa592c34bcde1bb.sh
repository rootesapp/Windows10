#Han.GJZS

settings get global enable_freeform_support