#Han.GJZS

grep_prop Customize_lu $Data_Dir/Random_Install_BootAnimation_Screen2.log