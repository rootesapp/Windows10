#Han.GJZS

printf '0|覆盖安装\n1|卸载重装'