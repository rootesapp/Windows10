#Han.GJZS

[[ $SDK -ge 26 && -lt 29 ]] && echo 1