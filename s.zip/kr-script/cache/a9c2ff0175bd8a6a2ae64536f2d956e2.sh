#Han.GJZS

settings get global show_hidden_icon_apps_enabled