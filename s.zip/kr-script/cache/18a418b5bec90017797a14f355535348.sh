#Han.GJZS

[[ $SDK -ge 24 ]] && echo 1