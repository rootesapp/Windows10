#Han.GJZS

. $ShellScript/Install_BootAnimation_Screen1_Page.sh