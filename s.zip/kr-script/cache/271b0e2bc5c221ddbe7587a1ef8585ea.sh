#Han.GJZS

[[ $SDK -lt 29 ]] && echo 1