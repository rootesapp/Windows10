#Han.GJZS

[[ $SDK -ge 28 ]] && echo 1