#Han.GJZS

[[ $SDK -ge 21 && -lt 27 ]] && echo 1