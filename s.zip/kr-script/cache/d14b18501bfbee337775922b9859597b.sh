#Han.GJZS

settings get secure clock_seconds