#Han.GJZS

. ./Install_BootAnimation_Screen1_Block.sh