#Han.GJZS

. ./switchs/Doze_Status_Get.sh