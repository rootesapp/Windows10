#Han.GJZS

[[ 0 = 0 ]] || echo 1