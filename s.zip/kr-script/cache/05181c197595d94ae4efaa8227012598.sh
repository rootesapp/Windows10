#Han.GJZS

[[ -d "/data/user/0/com.termux" ]] && echo 1