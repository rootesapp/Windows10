#Han.GJZS

. ./support/Check_is_AB_device.sh