#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上
echo "0|默认"
echo "Cai|彩虹电池图标"
echo "Lan|蓝色电池图标"
echo "Lv|绿色电池图标"
echo "TouMing|透明电池图标"
echo "BaiFenBi|竖型电池自带百分比"
echo "WaiXian|竖型电池自带电量外显"