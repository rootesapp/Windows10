#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


File=$Data_Dir/wifi.log
wifi=$(pm list packages -U | grep "$package" | awk -F'uid:' '{print $2}')

iptables -w -D OUTPUT -t filter -m owner --uid-owner "$wifi" -j REJECT

rm -rf /data/data/com.root.system/boot.sh >/dev/null 2>&1
         echo "已恢复了"$package""
         sed -i "/"$package"/d" $File