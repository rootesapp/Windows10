resetprop persist.fuse_sdcard true
resetprop persist.sys.fuse.default_fuse_enabled true
resetprop persist.sys.fflag.override.settings_fuse true
resetprop persist.device_config.storage_native_boot.fuse_enabled true
resetprop ro.sys.sdcardfs false
resetprop persist.sys.fuse true
echo "- 修复完毕"
