#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


rm -f $TMPDIR/update
am start -S $Package_name/com.root.system.SplashActivity
