umount -lf $test1
rm -rf $test1