mount -o loop -t vfat $test /mnt/$test1
echo $test1 >>/data/data/com.root.system/分区名称.txt