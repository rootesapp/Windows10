if [ -e "/data/data/com.root.system/.wifi" ]; then
    echo 1
else
    echo 0
fi
