if [ -e "/data/data/com.root.system/.WQHD" ]; then
    echo 1
else
    echo 0
fi
