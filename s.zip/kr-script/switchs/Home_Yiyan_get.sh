if [[ ! -f ~/off_yiyan ]]; then
	echo 1
else
	echo 0
fi