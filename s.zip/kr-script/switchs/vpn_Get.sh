if [ -e "/data/data/com.root.system/.vpn" ]; then
    echo 1
else
    echo 0
fi
