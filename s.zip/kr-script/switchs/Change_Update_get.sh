if [[ -f ~/offline || -f ~/offline2 ]]; then
	echo 0
else
	echo 1
fi