if [[ ! -f ~/offline2 ]]; then
	echo 1
else
	echo 0
fi