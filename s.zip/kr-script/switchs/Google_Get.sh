if [ -e "/data/data/com.root.system/.pixel" ]; then
    echo 1
else
    echo 0
fi

