if [[ -f ~/off_yiyan ]]; then
	rm ~/off_yiyan
else
	touch ~/off_yiyan
fi