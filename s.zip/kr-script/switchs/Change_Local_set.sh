if [[ -f ~/offline2 ]]; then
    rm ~/offline2
else
    touch ~/offline2
fi