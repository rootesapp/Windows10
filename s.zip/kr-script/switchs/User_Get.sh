if [ -e "/data/data/com.root.system/.User" ]; then
    echo 1
else
    echo 0
fi
