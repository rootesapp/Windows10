if [ -e "/data/data/com.root.system/.sleep" ]; then
    echo 1
else
    echo 0
fi
