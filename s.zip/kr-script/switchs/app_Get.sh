if [ -e "/data/data/com.root.system/.app" ]; then
    echo 1
else
    echo 0
fi
