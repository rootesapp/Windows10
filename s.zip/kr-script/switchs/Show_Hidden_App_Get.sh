[[ `settings get global show_hidden_icon_apps_enabled` = 1 ]] && echo 1 || echo 0
