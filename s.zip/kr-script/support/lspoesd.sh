#!/bin/bash

if pm path org.lsposed.manager > /dev/null 2>&1; then
    echo "1"
else
    echo "0"
fi
