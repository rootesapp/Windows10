#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


if [[ $SDK -lt 28 ]]; then
    echo 0
else
    echo 1
fi
