Configuration=2022091921
Magisk_Warehouse_version=2022091921
Show_Compatibility_Mode=1
MIUI=0


case "$1" in

#应用
com.topjohnwu.magisk)
apk='com.topjohnwu.magisk'
name='magisk'
version='27000'
versionCode=27000
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
time='2021年5月29号'
    [[ $Choice = 1 ]] && Download -gitee2 "Magisk-Stable-27000.apk" "$1.apk" '12498796' '' "$1.apk"
;;
com.miui.miwallpaper)
apk='com.miui.miwallpaper'
name='miui壁纸'
version='ALPHA-2.6.170-01121113-ogl'
versionCode=19
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
time='2021年5月29号'
    [[ $Choice = 1 ]] && Download -gitee2 "MIUI壁纸.apk" "$1.apk" '97766' '' "$1.apk"
;;

com.miui.miwallpaper.moon)
apk='com.miui.miwallpaper.moon'
name='月球超级壁纸'
version='ALPHA-2.6.170-01121113-ogl'
versionCode=19
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
time='2021年5月29号'
    [[ $Choice = 1 ]] && Download -gitee2 "sms.apk" "$1.apk" '97766' '' "$1.apk"
;;

com.miui.miwallpaper.snowmountain)
apk='com.miui.miwallpaper.snowmountain'
name='雪山'
version='ALPHA-2.6.170-01121113-ogl'
versionCode=19
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
time='2021年5月29号'
    [[ $Choice = 1 ]] && Download -gitee2 "SuperWallpaperSnowmountain_v2.6.555_danji100.com.apk" "$1.apk" '97766' '' "$1.apk"
;;

com.miui.miwallpaper.mars)
apk='com.miui.miwallpaper.mars'
name='火星'
version='ALPHA-2.3.56-04251316'
versionCode=19
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
time='2021年5月29号'
    [[ $Choice = 1 ]] && Download -gitee2 "hxcjbz.apk" "$1.apk" '97766' '' "$1.apk"
;;


#Magisk模块

safetynet-fix1)
Show_Compatibility_Mode=0
id='safetynet-fix'
name='Magisk仓库正在维护，后面会开放'
version='v2.4.0'
versionCode=200
author='前面的区域以后再来探索吧'
description='前面的区域以后再来探索吧'
    [[ $Choice = 1 ]] && Download -gitee "小岩隐藏BL锁.zip" "$1.zip" '33719' '' "$1.zip"

;;



safetynet-fix)
Show_Compatibility_Mode=0
id='safetynet-fix'
name='隐藏BL锁'
version='v2.4.0'
versionCode=200
author='小岩 作者qq1318547810'
description='针对Android 8-13 设备上的SafetyNet和Play Integrity的通用修复程序，并进行了硬件认证'
    [[ $Choice = 1 ]] && Download -gitee "小岩隐藏BL锁.zip" "$1.zip" '33719' '' "$1.zip"

;;

HcFkDD)
Show_Compatibility_Mode=0
id='HcFkDD'
name='Fuck dd格机'
version='v2.03'
versionCode=203
author='HChai'
description='本模块拦截能力有限请勿乱刷模块，防止Magisk模块格机和MT脚本格机。加密脚本与模块都可拦截（软件中招没办法）请勿作死尝试'
    [[ $Choice = 1 ]] && Download -gitee "拦截FuckDD.zip" "$1.zip" '24982' '' "$1.zip"

;;

Hideinit)
Show_Compatibility_Mode=0
id='Hideinit'
name='隐藏init.rc被修改'
version='v2024.03.10'
versionCode=20240310
author='By 小岩 & qq1318547810'
description='用魔法尝试隐藏init.rc被修改的痕迹，让Momo检测不到init.rc被修改'
    [[ $Choice = 1 ]] && Download -gitee "隐藏init.rc被修改.zip" "$1.zip" '33719' '' "$1.zip"

;;

momohidesuper)
Show_Compatibility_Mode=0
id='momohidesuper'
name='隐藏环境（超级版）'
version='v1.0.0'
versionCode=1
author='小岩 作者qq1318547810'
description='隐藏momo的各种环境异常，root请自行隐藏，仅限于官方系统和类原生系统，官改自测（官改刷入可能变砖，请自备救砖模块）'
    [[ $Choice = 1 ]] && Download -gitee "隐藏环境(超级版).zip" "$1.zip" '33719' '' "$1.zip"

;;

Model_Camouflage)
id='Model_Camouflage'
name='机型伪装'
version='v114514'
versionCode='114514'
author='People11'
description='通过Magisk修改prop达到机型伪装'
time='2021年8月8号'
;;

Convert_to_system_app)
id='Convert_to_system_app'
name='第三方应用转系统应用'
version='v1.2'
versionCode='2'
author='Han | 情非得已c'
description='自定义方式使用模块方式将三方应用转为系统应用'
time='2021年5月29号'
;;

StopWriteDev)
Show_Compatibility_Mode=0
id='StopWriteDev'
name='Hc-百分百防格机'
version='v2'
versionCode=200
author='HChai'
description='通过某种xxx防止软件、模块、脚本格机 [开机后60~120s内随机启动保护]'
time='2021年4月30号'
    [[ $Choice = 1 ]] && Download -gitee "StopWriteDev.zip" "$1.zip" '102660' '' "$1.zip"

;;


Freezing_system_app)
id='Freezing_system_app'
name='使用Magisk模块方式冻结系统应用'
version='v1'
versionCode='1'
author='by：Han | 情非得已c'
description="$name"
time='2020年8月9号'
;;

Convert_to_system_app)
id='Convert_to_system_app'
name='三方应用转系统应用'
version='v1.2'
versionCode='2'
author='by：Han | 情非得已c'
description='自定义方式使用模块方式将三方应用转为系统应用'
time='2020年8月20号'
;;

Remove_Temperature_Control)
id='Remove_Temperature_Control'
name='移除温控'
version='v2021021300'
versionCode=9
author='by：Han | 情非得已c'
description='用途：Magisk模块方式移除温控文件'
time='2021年2月13号'
;;

Clone_Configuration)
id=Clone_Configuration
name=克隆主用户EDXposed模块配置
version='v2021021402'
versionCode=2
author='by：Han | 情非得已c'
description='免双开EDXposed Manager和Xposed模块，使双开应用同步主用户Xposed模块配置'
time='2021年2月14号'
;;

wifi-bonding)
Show_Compatibility_Mode=0
id='wifi-bonding'
name='Wifi Bonding - 让Wi-Fi带宽提速（高通）'
version='1.14'
versionCode='15'
author='simonsmh'
description='Doubles your wi-fi bandwith by modifying WCNSS_qcom_cfg.ini（通过修改WCNSS_qcom_cfg.ini，让Wi-Fi带宽提速至最大）'
time='2020年12月13号'
    [[ $Choice = 1 ]] && . ./Magisk_Module/$1.sh
;;

Model_Camouflage)
id='Model_Camouflage'
name='机型伪装'
version='v1'
versionCode='1'
author='by：Han | 情非得已c'
description='原理：通过Magisk修改prop达到机型伪装。'
time='2020年6月15号'
;;

SELinux_OFF)
Show_Compatibility_Mode=0
id='SELinux_OFF'
name='关闭SELinux'
version='v1.3'
versionCode='3'
author='by：Han | 情非得已c'
description='在每次重启/开机时，自动关闭SELinux/宽容模式/Permissive，针对部分模块需要关闭SELinux才能正常开机，以及部分Xposed模块需要关闭才生效，除非你很清楚关闭SELinux后果，否则不推荐使用本模块'
time='2021年2月7号'
    [[ $Choice = 1 ]] && . ./Magisk_Module/$1.sh
;;

SELinux_ON)
Show_Compatibility_Mode=0
id='SELinux_ON'
name='开启SELinux'
version='v1.3'
versionCode='3'
author='by：Han | 情非得已c'
description='在每次重启/开机时，自动开启SELinux/严格模式/强制模式/Enforcing，针对部分官改ROM系统默认关闭SELinux'
time='2021年2月7号'
    [[ $Choice = 1 ]] && . ./Magisk_Module/$1.sh
;;

List="
EdXposed_Manager-4.5.7 (45700).apk
Alpha-EdXposed-YAHFA-v0.4.6.4(4563).zip
Alpha-EdXposed-SandHook-v0.4.6.4(4563).zip
"
[[ $Old_YAHFA = 1 ]] && Download -chaoxing "4d9ab34e8827ec43cec8b7c2c5e46d13" "riru_edxposed-4563.zip" 2861079 ebb0129db6b2080246e11a4607cad926 "riru_edxposed-4563.zip"
[[ $Old_SandHook = 1 ]] && Download -chaoxing "cfda358da69f244191281bfab0b12635" "riru_edxposed_sandhook-4563.zip" 3092528 6791a626ef893fb2a15047eb35d88620 "riru_edxposed_sandhook-4563.zip"
;;

exit_sideload)
    Download_File="$PeiZhi_File/$1.zip"
;;

Card_Brush_Bag)
    Download_File="$PeiZhi_File/Card_Brush_Bag/$3.zip"
;;

Redmi-K30-5G-recovery)
List="
Redmi-K30-5G-3.4.1B-0313-wzsx150.img
Redmi-K30-5G-3.4.2B-0623-wzsx150.img"
    [[ $Version = 11 ]] && Download -chaoxing "166301783655357433142c94b4a3be74" "Redmi-K30-5G-11-3.4.1B-0623-wzsx150.img" 134217728 941a7ff1f4de4745b9bdd68bf895bd9f "Redmi-K30-5G-11"
    [[ $Version = 12 ]] && Download -chaoxing "a03118a561c42401aa9e8dc5befc48db" "Redmi-K30-5G-12-3.4.2B-0313-wzsx150.img" 134217728 1a734c45512fbbecd79bb861e74968ca "Redmi-K30-5G-12"
;;

MIUI)
    MIUI -chaoxing "6b300835f03cd5b53f2b87e75f030d45" MIUI1.4.7.zip 6504587 ba44181b58d10929b7ae1fc3293dd659 MIUI
;;

Charging_Sound_Effect)
    versionCode=1
    [[ $Choice = 1 ]] && Download -chaoxing "e2975efdc24595a6d4ce8a39f175eea9" "$1.zip" 6297837 bb400cbb13333d3d68dc73dc4f6d3dee "$1.zip"
;;

BootAnimation_Screen1)
    BootAnimation_Screen1 -chaoxing "7f39e5a919a6300a4b90dbd4af6d6929" "$1.zip" 10697488 8a69c474a8287108a1a79b01146349a7 "$1.zip" 18
;;

Zipsigner)
    Download -gitee "zipsigner-master.zip" "$1.zip" '5206525' '' "$1.zip"
;;

payload_dumper-win64)
    [[ $Choice = 1 ]] && Download -chaoxing "35e02784d1d210637b564dc03c238947" "$1.zip" 6755703 20029a0740cba709789ad074949bf5fa "$1.zip"
;;

Xposed_rovo89)
    if [[ $2 = -install ]]; then
        v=89
        SDK2=$SDK/$Type
            case $SDK in
            21)
                if [[ $Type = arm ]]; then
                    Download -chaoxing "8165c1be5ecbc9e474319b8ab5fc5431" "xposed-v$v-sdk$SDK-$Type.zip" 3480379 614d01a116809abf09cadfd7a1abc8f2 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "375bb2ff8053b1fc62ceb77e395e40b2" "xposed-v$v-sdk$SDK-$Type.zip" 5853627 0a460e9f52ddb3e9ba1f389badd7bd6e "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "1a0cc8e1b7a768c92f7da0513a733c33" "xposed-v$v-sdk$SDK-$Type.zip" 4012550 be4b512111cc3efc45d8cb85e07173c2 "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            22)
                if [[ $Type = arm ]]; then
                    Download -chaoxing "0f65edc29b9ceab8d8d71a408588d748" "xposed-v$v-sdk$SDK-$Type.zip" 3561425 80fff79c7ad85141c520e5fd0c644ec7 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "3f33bf8c9290f0ff9c5ad18de75e0510" "xposed-v$v-sdk$SDK-$Type.zip" 5969129 4d3bac2357dd004afff54cc48cb18fff "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "2d19eae768916c8a29f536288610f9da" "xposed-v$v-sdk$SDK-$Type.zip" 4094816 050a3d6cf4468556f2f87c9526b9e30e "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            23)
                if [[ $Type = arm ]]; then
                    Download -chaoxing "cd1d5f26454d32eb93f3cb845bf0ce91" "xposed-v$v-sdk$SDK-$Type.zip" 4874299 9361a270336427455c7e09af5f9c6969 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "00dceb8801dbe1110e9e8e37bbc33b0f" "xposed-v$v-sdk$SDK-$Type.zip" 8206844 bdaee35f5c9239d399d75ca25e89db7c "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "e479c26ae2e3c62351f2d6679e546f72" "xposed-v$v-sdk$SDK-$Type.zip" 5715178 973c8a8725d7a0bcbd718ce1f8cfa31c "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            24)
                if [[ $Type = arm ]]; then
                    Download -chaoxing "76f9050c3d75aea074a13ab792e49af7" "xposed-v$v-sdk$SDK-$Type.zip" 4389429 f6fcabd71339d549699e62524f7d6c1f "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "6ca94dd50f22e5d90820eeece115804e" "xposed-v$v-sdk$SDK-$Type.zip" 8238874 1e867e70bae5e6b38cdf937b8e79df37 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "f2f33c8f383de8341b493299ff8f3d4a" "xposed-v$v-sdk$SDK-$Type.zip" 5191178 44696b7092a69a263160365a6c058b41 "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            25)
                if [[ $Type = arm ]]; then
                    Download -chaoxing "6952180efe50cb8ec187ea2964cc54ac" "xposed-v$v-sdk$SDK-$Type.zip" 4405400 778dd744f0dfa6bd7608ae17281c0faa "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "9ea8b36189e651d8d4ac499b21b3bfce" "xposed-v$v-sdk$SDK-$Type.zip" 8272548 3039d5169746025a075a3bf297af2f86 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "e5ff017dd3b382d3d00257eabbe91a59" "xposed-v$v-sdk$SDK-$Type.zip" 5206379 544f993de6ec2be20583a23116c342de "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            26)
                v=90
                if [[ $Type = arm ]]; then
                    Download -chaoxing "1c54a0066d121ec46dc3d2509ecfc113" "xposed-v$v-sdk$SDK-$Type.zip" 4277017 405ee87d04741bbfbbd0a02ffb938428 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "e880441995ff43009b9ddae41d43d2e9" "xposed-v$v-sdk$SDK-$Type.zip" 8068001 a18f89a0470b126ac5dfe7e0ed2d5d0c "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "f273aaeee63f003e1d61ea6e846e952e" "xposed-v$v-sdk$SDK-$Type.zip" 4770182 e68569d68dc6b9badeb2f41cd87bbe87 "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            27)
                v=90
                if [[ $Type = arm ]]; then
                    Download -chaoxing "5c80f0ef769c62acc18aad105da7210a" "xposed-v$v-sdk$SDK-$Type.zip" 4229826 fa6b26bec7d95b41716ebdc746e4d576 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = arm64 ]]; then
                    Download -chaoxing "744620c0c12bf10aa4c97a33ad55353c" "xposed-v$v-sdk$SDK-$Type.zip" 8038926 1085eb845483523a1b5a30547f24fc46 "xposed-v$v-sdk$SDK-$Type.zip"
                elif [[ $Type = x86 ]]; then
                    Download -chaoxing "8e8a18e173a33065bf4ef5728ede3766" "xposed-v$v-sdk$SDK-$Type.zip" 4963220 69705e2d5c6e88815d7f984f69d03200 "xposed-v$v-sdk$SDK-$Type.zip"
                fi
            ;;
            *)
                abort "！原版Xposed不支持您的设备SDK：$SDK"
            esac

    elif [[ $2 = -uninstall ]]; then
        SDK2=uninstall
        case $SDK in
            21 | 22 | 23 | 24 | 25 | 26 | 27) :;;
            *) abort "！原版Xposed不支持您的设备SDK：$SDK";;
        esac
            if [[ $Type = arm ]]; then
                Download -chaoxing "81c31dee7144c0b1781087107b4deb28" "xposed-uninstaller-20180117-$Type.zip" 311568 d4d2fa1d22779d70d3be10a0b920aaea "xposed-uninstaller-20180117-$Type.zip"
            elif [[ $Type = arm64 ]]; then
                Download -chaoxing "81c31dee7144c0b1781087107b4deb28" "xposed-uninstaller-20180117-$Type.zip" 311568 d4d2fa1d22779d70d3be10a0b920aaea "xposed-uninstaller-20180117-$Type.zip"
            elif [[ $Type = x86 ]]; then
                Download -chaoxing "89416ad6ff5022f245f4d5c013b86462" "xposed-uninstaller-20180117-$Type.zip" 455283 87846dd6c7fe48eabbe2763c4dd6cb86 "xposed-uninstaller-20180117-$Type.zip"
            fi
        fi
;;

BootAnimation_Screen2)
    if [[ $2 = Harmony_OS ]]; then
        Download -chaoxing "275fba27d2310802aa8463907c81ad96" "$2.zip" 96187051 2e418d056841d638d3b522bde3dd1f12 "$2.zip"
    elif [[ $2 = DotOS ]]; then
        Download -chaoxing "1985180522be0061ee4762d8de8869b1" "$2.zip" 8557408 1cad1b8d9d84ad1064a6aebad0fb3c22 "$2.zip"
    elif [[ $2 = Google_Dark ]]; then
        Download -chaoxing "918e930da914c05416919f91b98174ad" "$2.zip" 2415413 24ec7a08c55fdf908995ea9c99bfd15c "$2.zip"
    elif [[ $2 = Google_White ]]; then
        Download -chaoxing "6fbd8f0d1de49dd2a61fa49289414215" "$2.zip" 2431275 8582603d8b8e5b3c184416ca384e3983 "$2.zip"
    elif [[ $2 = 2233_Pink ]]; then
        Download -chaoxing "cf06d58bf9b6961e4898154f35810a86" "$2.zip" 19659178 3847a30ee173b3be44548c8bfbac404b "$2.zip"
    elif [[ $2 = 2233_Blue ]]; then
        Download -chaoxing "363313a2108804a891abff0c4da24ac8" "$2.zip" 12037019 b8a8f960eec94753a93e21a71acc64d1 "$2.zip"
    elif [[ $2 = MIUI11 ]]; then
        Download -chaoxing "20eb4b07d7fed7ebd01b2c2678d36bef" "$2.zip" 33852072 63059bb9857720d83f418ce1ec062486 "$2.zip"
    elif [[ $2 = Scary_EP ]]; then
        Download -chaoxing "14d2be9d536e050f015f50336acf0550" "$2.zip" 12246016 cc47ea9fc3e5984a23cae71b9b02f9fb "$2.zip"
    elif [[ $2 = Scary_MI ]]; then
        Download -chaoxing "28ec7ac08129c576393c3e83784641b0" "$2.zip" 14386690 e49820c65d6dae3158a7263f6e239022 "$2.zip"
    elif [[ $2 = Scary_OnePlus ]]; then
        Download -chaoxing "aaf3748878b21c34a7e6414e3687a48b" "$2.zip" 9387253 e9888de8d5458b1265e2b912abc02955 "$2.zip"
    elif [[ $2 = OnePlus_2077 ]]; then
        Download -chaoxing "96292c903e368127a219b59eb1cad959" "$2.zip" 70335956 a67184db7350916de41e62e028ec01a3 "$2.zip"
    elif [[ $2 = ROG2 ]]; then
        Download -chaoxing "36df722607c5f8806e20c49f5de329be" "$2.zip" 12758779 cdd773fd2148844948417dc985893016 "$2.zip"
    elif [[ $2 = LittleFox ]]; then
        Download -chaoxing "ad8ca3a80ab771c6c4bac8989707aab6" "$2.zip" 2138454 607fa72c3440fd6ba7a7071133671dc8 "$2.zip"
    elif [[ $2 = iOS ]]; then
        Download -chaoxing "c8499a8c352f48dae19a504ea06d2543" "$2.zip" 20501 f28958c51c65dc9718673cb29c902dd0 "$2.zip"
    elif [[ $2 = Horizon_Line_1920 ]]; then
        Download -chaoxing "08dc60fc5154f04167baceab03698897" "$2.zip" 116540719 fdb2aa8511ac17eb88cc4f76d2451dff "$2.zip"
    elif [[ $2 = Horizon_Line_2400 ]]; then
        Download -chaoxing "f31321e5a6ce1a4c6e4bfc7d3d064ca5" "$2.zip" 116540719 99705fbbae0a2d017c3913151f3417a6 "$2.zip"
    elif [[ $2 = KOBE_1920 ]]; then
        Download -chaoxing "069ec3dbcca9ce2ae083be458580ed33" "$2.zip" 108363348 347cb7b4d8e88595791cf08a00172bc5 "$2.zip"
    elif [[ $2 = KOBE_2400 ]]; then
        Download -chaoxing "e5b99815e268d711a9a53259be94ad56" "$2.zip" 108363348 72f3226747ec099a3934a6a29eea096a "$2.zip"
    elif [[ $2 = Your_Name_1920 ]]; then
        Download -chaoxing "271fd5a4d242bed47ffd175bb5557856" "$2.zip" 116114234 87a17012955b38213a18213de2b050db "$2.zip"
    elif [[ $2 = Your_Name_2400 ]]; then
        Download -chaoxing "f38e76e3262f561437a8881c7e10fd03" "$2.zip" 116114234 7bf9e3b9c1cefb154e45c05f7c2eb9fe "$2.zip"
    elif [[ $2 = Kang_In_Kyung_1920 ]]; then
        Download -chaoxing "1dc9013fb47598cb350249406fc190dd" "$2.zip" 345712297 7649c8b3d1feb855fb7897c4c3fd93f2 "$2.zip"
    elif [[ $2 = Kang_In_Kyung_2400 ]]; then
        Download -chaoxing "c71c018ac1e70ece465f1b77377d594a" "$2.zip" 345786085 704b88462902bc774c8791bcd6c49257 "$2.zip"
    fi
;;

com.miui.miwallpaper)
    version='ALPHA-2.6.205-03082129-ogl'
    versionCode=206000205
    [[ $Choice = 1 ]] && Download -chaoxing "759f197ea653fa1aa77e9ecd9a8145f6" "$1.apk" 56406991 124a1dd155294d05827264f253ce860f "$1.apk"
;;

com.miui.miwallpaper.snowmountain)
    version='ALPHA-2.6.151-12171721-ogl'
    versionCode=206000151
    [[ $Choice = 1 ]] && Download -chaoxing "2074310d5fe7ada4c619b5bd9b4ab07e" "$1.apk" 89837236 f5c971e0e6735ab653b4dd8f0bbbc6ac "$1.apk"
;;

#Install_Applet)
 #   name=Applet
  #  versionCode=73
   # Install_Applet -gitee2 "Applet.zip" "$name.zip" 7362205 "$name" $versionCode
#;;


Install_Applet)
    name=Applet
    versionCode=73
    Download_File=$Other/$name.zip
    Install_Applet2
;;

binwalk)
    version=2.3.1
    Download -chaoxing "bf067bc9d817c3d9f9d6748db38d3bdc" "$1.zip" 39656863 023e3f4d48ecf496a67d283c071d3129 "$1.zip"
;;

Install_busybox)
    name="busybox_$Type"
    [[ $Type = arm ]] && Start_Install -chaoxing "a4c1c88bb2fbb63bb6917b4eafaf6695" "$name-selinux" 1452044 92a3d5c291124e5b8bd4d7b04c24362d "$name" 1.33.1 13310
    [[ $Type = arm64 ]] && Start_Install -chaoxing "56732ce948d64c7be1636cfe861e9160" "$name-selinux" 2066520 2340fc8c0f18462fc0dffe9e591c5c01 "$name" 1.33.1 13310
    [[ $Type = x86 ]] && Start_Install -chaoxing "5cbe4922728b00510cc85b48140e761a" "$name-selinux" 2094872 cd5fde5c345e711657709599f348e260 "$name" 1.33.1 13310
    [[ $Type = x86_64 ]] && Start_Install -chaoxing "3d7613fe56d688a6a74897eb51b88ecb" "$name-selinux" 2222408 195292917f4c3a3815ed352cac3bda99 "$name" 1.33.1 13310
    [[ $Type = mips ]] && Start_Install -chaoxing "5c1a1cf0dcd3904716b4fcbfbf7fc946" "$name" 1918732 7886ed84533e344c0ea0e87ff0578749 "$name" 1.33.1 13310
    [[ $Type = mips64 ]] && Start_Install -chaoxing "2c82856e359a311e26e574c0e16388c1" "$name" 1939440 c8c7311463e2999af63540c51628364e "$name" 1.33.1 13310
;;

*)
    abort "！未找到$1服务"
;;
esac
true