#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


Choice=1
. $Load com.topjohnwu.magisk
cp -rf "$Download_File" "$File_Dir/$name-v$version（$versionCode）.zip"
echo
echo "- 已下载到$File_Dir/$name-v$version（$versionCode）.zip"
