#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上

echo "Lenovo|Lenovo联想系列"
echo "oppo|OPPO/一加/realme系列"
echo "Google_Pixel|Google Pixel系列"
