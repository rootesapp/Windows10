fastboot oem unlock-go; fastboot oem unlock|fastboot oem unlock
fastboot oem unlock-go
fastboot flashing unlock
fastboot flashing unlock_critical
fastboot bbk unlock_vivo
